package isac;

import java.awt.Color;

import javax.swing.*;

public class Icoffeandtea extends JPanel{

	Icoffeandtea()
	{
		setBackground(Color.black);
	}
}
