package isac;

import java.awt.Color;

import javax.swing.*;

public class Itoast extends JPanel{

	Itoast()
	{
		setBackground(Color.black);
	}
	
	
}
