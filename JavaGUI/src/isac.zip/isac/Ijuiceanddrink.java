package isac;

import java.awt.Color;

import javax.swing.*;

public class Ijuiceanddrink extends JPanel{

	Ijuiceanddrink()
	{
		setBackground(Color.black);
	}
}
