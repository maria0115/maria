package isac;

import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.lang.*;
import javax.swing.event.*;

public class Builds extends JPanel{

	JTextField tf;
	JButton b;
	int result;

	Mainisac isa;
	public Builds(Mainisac isa)
	{
		this.isa=isa;
		//Mainisac isac = new Mainisac();
		Builds1();
		getResult();
		
		
	}
	
	
	public void setResult(int result) {
		this.result = result;
		System.out.println(result);
	}


	public int getResult() {
		return result;
	}


	void Builds1()
	{
		//this.=isa.total1;
		//tf = new JTextField(Integer.toString(total),40);
		tf = new JTextField(Integer.toString(result));
		
		b = new JButton("하이");
		setLayout(new BorderLayout());
		add(tf, BorderLayout.SOUTH);
		add(b, BorderLayout.NORTH);
	}
	
}
